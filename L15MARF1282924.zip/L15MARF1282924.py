# Semana No. 12: Ejercicio 1

print("Semana No. 12: Ejercicio 1")

# Definir funciones para calcular áreas
def ObtenerAreaTriangulo(base, altura):
    return (base * altura) / 2

def ObtenerAreaCuadrado(lado):
    return lado ** 2

def ObtenerAreaRectangulo(base, altura):
    return base * altura

def ObtenerAreaCirculo(radio):
    import math
    return math.pi * (radio ** 2)

# Mostrar menú al usuario
print("Seleccione una opción:")
print("a. Área de triángulo")
print("b. Área de cuadrado")
print("c. Área de rectángulo")
print("d. Área de círculo")

opcion = input("Ingrese su opción: ")

if opcion == "a":
    base = float(input("Ingrese la base del triángulo: "))
    altura = float(input("Ingrese la altura del triángulo: "))
    area = ObtenerAreaTriangulo(base, altura)
    print(f"El área del triángulo es: {area:.2f}")

elif opcion == "b":
    lado = float(input("Ingrese el lado del cuadrado: "))
    area = ObtenerAreaCuadrado(lado)
    print(f"El área del cuadrado es: {area:.2f}")

elif opcion == "c":
    base = float(input("Ingrese la base del rectángulo: "))
    altura = float(input("Ingrese la altura del rectángulo: "))
    area = ObtenerAreaRectangulo(base, altura)
    print(f"El área del rectángulo es: {area:.2f}")

elif opcion == "d":
    radio = float(input("Ingrese el radio del círculo: "))
    area = ObtenerAreaCirculo(radio)
    print(f"El área del círculo es: {area:.2f}")

else:
    print("Opción inválida")

# Semana No. 12: Ejercicio 2

# Inicializar variables globales
x = 0
y = 0

def MoverHaciaArriba():
    """Mueve el objeto hacia arriba incrementando Y."""
    global x, y
    x = x
    y = y + 1

def MoverHaciaAbajo():
    """Mueve el objeto hacia abajo decrementando Y."""
    global x, y
    x = x
    y = y - 1

def MoverHaciaLaDerecha():
    """Mueve el objeto a la derecha incrementando X."""
    global x, y
    x = x + 1
    y = y

def MoverHaciaLaIzquierda():
    """Mueve el objeto a la izquierda decrementando X."""
    global x, y
    x = x - 1
    y = y

while True:
    # Mostrar menú al usuario
    print("Seleccione una opción:")
    print("1. Arriba")
    print("2. Abajo")
    print("3. Izquierda")
    print("4. Derecha")
    print("5. Salir")

    opcion = input("Ingrese su opción: ")

    if opcion == "1":
        MoverHaciaArriba()
    elif opcion == "2":
        MoverHaciaAbajo()
    elif opcion == "3":
        MoverHaciaLaIzquierda()
    elif opcion == "4":
        MoverHaciaLaDerecha()
    elif opcion == "5":
        # Mostrar coordenadas finales cuando el usuario selecciona "salir"
        print("Coordenadas finales del objeto: " + str(x) + "," + str(y))
        break
    else:
        print("Opción inválida")