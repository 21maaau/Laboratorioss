
# Presentar nombre
nombre = "EJERCICO T11 MAURICIO ALEJANDRO RUIZ 1282924"
print(nombre)

# Solicitar al usuario el valor de x
x = int(input("Ingresa un número entero mayor a 0): "))

# Solicitar al usuario el valor de a
a = int(input("Ingresa un número entero mayor a 0): "))

# Solicitar al usuario el valor de n
n = 0
while n <= 0:
    n = int(input("Ingresa el valor de n, que sea un número entero mayor a 0): "))
    if n <= 0:
        print("Por favor, ingresa un número entero positivo.")

# Calcular y mostrar la Serie c
serie_c = 0
k = 0
while k <= n:
    serie_c += x**k * a**(n - k)
    k += 1

print("\nSerie c:")
k = 0
while k <= n:
    print(f"{x}^{k} * {a}^{n}-{k}", end=" ")
    if k < n:
        print("+", end=" ")
    k += 1

print("=", serie_c)
print("Espero te haya servido mi herramienta!")