print("Semana 10, ejercicio: 3")

año = int(input("Ingrese su año de nacimiento: "))

if año < 2025:
    mes = int(input("Ingrese su mes de nacimiento con números del 1 al 12: "))

    if mes in range(1, 13):
        día = int(input("Ingrese su día de nacimiento: "))
        
        if día in range(1, 32):
            if (mes == 3 and día in range(21, 32)) or (mes == 4 and día in range(1, 21)):
                print("Tu signo zodiacal es: Aries")
            elif (mes == 4 and día in range(20, 31)) or (mes == 5 and día in range(1, 21)):
                print("Tu signo zodiacal es: Tauro")
            elif (mes == 5 and día in range(21, 32)) or (mes == 6 and día in range(1, 21)):
                print("Tu signo zodiacal es: Géminis")
            elif (mes == 6 and día in range(21, 31)) or (mes == 7 and día in range(1, 23)):
                print("Tu signo zodiacal es: Cáncer")
            elif (mes == 7 and día in range(23, 32)) or (mes == 8 and día in range(1, 23)):
                print("Tu signo zodiacal es: Leo")
            elif (mes == 8 and día in range(23, 32)) or (mes == 9 and día in range(1, 23)):
                print("Tu signo zodiacal es: Virgo")
            elif (mes == 9 and día in range(23, 31)) or (mes == 10 and día in range(1, 23)):
                print("Tu signo zodiacal es: Libra")
            elif (mes == 10 and día in range(23, 32)) or (mes == 11 and día in range(1, 22)):
                print("Tu signo zodiacal es: Escorpio")
            elif (mes == 11 and día in range(22, 31)) or (mes == 12 and día in range(1, 22)):
                print("Tu signo zodiacal es: Sagitario")
            elif (mes == 12 and día in range(22, 32)) or (mes == 1 and día in range(1, 20)):
                print("Tu signo zodiacal es: Capricornio")
            elif (mes == 1 and día in range(20, 32)) or (mes == 2 and día in range(1, 19)):
                print("Tu signo zodiacal es: Acuario")
            elif (mes == 2 and día in range(19, 29)) or (mes == 3 and día in range(1, 21)):
                print("Tu signo zodiacal es: Piscis")
            else:
                print("Fecha inválida.")
        else:
            print("Error: el día debe estar entre 1 y 31")
    else:
        print("Error: el mes debe estar entre 1 y 12")
else:
    print("Por favor ingrese una fecha válida.")