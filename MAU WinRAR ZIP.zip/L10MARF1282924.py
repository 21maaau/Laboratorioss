print("Semana no. 10: Ejercicio 1")
mes = int(input("Ingrese un número entre 1 y 12: "))

if mes < 1 or mes > 12:
    print("Error: el número debe estar entre 1 y 12")
else:
    # Validando
    if mes == 1:
        print("Mes: enero")
    elif mes == 2:
        print("Mes: febrero")
    elif mes == 3:
        print("Mes: marzo")
    else:
        print("Es otro mes")

    # Validando con match
    match mes:
        case 1:
            print("Mes: enero")
        case 2:
            print("Mes: febrero")
        case 3:
            print("Mes: marzo")
        case _:
            print("Es otro mes")

print("Semana 10: Ejercicio 2")

# Convertir las entradas a números enteros
A = int(input("Ingrese el primer numero: "))
B = int(input("Ingrese el segundo numero: "))
C = int(input("Ingrese el tercer numero: "))

# Encontrar el mayor de los tres números
if A > B:
    if A > C:
        print("El mayor es:", A)
    elif A == C:
        print("Los mayores son:", A, "y", C)
    else:
        print("El mayor es:", C)
elif A == B:
    if A > C:
        print("Los mayores son:", A, "y", B)
    elif A == C:
        print("Los tres valores son iguales")
    else:
        print("El mayor es:", C)
else:
    if B > C:
        print("El mayor es:", B)
    elif B == C:
        print("Los mayores son:", B, "y", C)
    else:
        print("El mayor es:", C)
