import random

def LlenarVector(arreglo):
    for i in range(10):
        r = random.randint(1, 100)
        arreglo.append(r)
    return arreglo

def Promedio(arreglo):
    sumatoria=0
    for valor in arreglo:
        sumatoria+=valor
    return sumatoria/len(arreglo)

def ParesImpares(arreglo):
    sumapar=0
    sumaimpar=0
    for i in range(len(arreglo)):
        if i%2==0:
            sumapar+=arreglo[i]
        else:
            sumaimpar+=arreglo[i]
    print("La suma de los elementos pares es: ", sumapar)
    print("La suma de los elementos impares es: ", sumaimpar)

def ContarParImpar(matriz):
    par=0
    impar=0
    for i in range(len(matriz)):
        for j in range(len(matriz[i])):
            if matriz[i][j]%2==0:
                par+=1
            else:
                impar+=1
    print("la cantidad de números pares es:", par)
    print("la cantidad de números impares es:", impar)

def MinMax(matriz):
    minimo = matriz[0][0]
    maximo = matriz[0][0]
    for i in range(len(matriz)):
        for j in range(len(matriz[i])):
            if matriz[i][j] < minimo:
                minimo = matriz[i][j]
            elif matriz[i][j] > maximo:
                maximo = matriz[i][j]
    print("El número menor es:", minimo)
    print("El número mayor es:", maximo)

print("Semana No. 16: Ejercicio 1")
vector = []
vector = LlenarVector(vector)
print(vector)
print("El promedio es:", Promedio(vector))
print("Longitud del arreglo:", len(vector))
ParesImpares(vector)

#Ejercicio2
print("\nSemana No. 16: Ejercicio 2")

filas = int(input("Ingrese la cantidad de filas: "))
columnas = int(input("Ingrese la cantidad de columnas: "))

matriz = []

for i in range(filas):
    for j in range(columnas):
        temp = []
        r = random.randint(0, 1000)
        temp.append(r)
    matriz.append(temp)
print(matriz)
ContarParImpar(matriz)
MinMax(matriz)